document.addEventListener("DOMContentLoaded", function () {

  const buttons = document.querySelectorAll(".search ul li");
  const ul = document.querySelector("#content ul");

  buttons.forEach(function (btn) {
    btn.addEventListener("click", function () {

      const lis = Array.from(document.querySelectorAll("#content ul > li"));
      const ab = this.className;

      const strName = ab;
      slideTarget(strName.substr(4, 1));

      function slideTarget(n) {

        let datelis;

        if (n == 0) {
          // 날짜 내림차순
          datelis = lis.sort(function (a, b) {
            const dateA = new Date(a.querySelector("span.date").textContent);
            const dateB = new Date(b.querySelector("span.date").textContent);
            return dateB - dateA;
          });

        } else if (n == 1) {
          // 가격 내림차순
          datelis = lis.sort(function (a, b) {
            const priceA = parseInt(a.querySelector("span.price").textContent.replace(/[^0-9]/g, ""));
            const priceB = parseInt(b.querySelector("span.price").textContent.replace(/[^0-9]/g, ""));
            return priceB - priceA;
          });

        } else {
          // 가격 오름차순
          datelis = lis.sort(function (a, b) {
            const priceA = parseInt(a.querySelector("span.price").textContent.replace(/[^0-9]/g, ""));
            const priceB = parseInt(b.querySelector("span.price").textContent.replace(/[^0-9]/g, ""));
            return priceA - priceB;
          });
        }

        // DOM 재정렬
        if (datelis) {
          ul.innerHTML = "";
          datelis.forEach(function (li) {
            ul.appendChild(li);
          });
        }
      }

    });
  });

});