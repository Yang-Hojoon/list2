$(function() {
 $('select').on("change", function () {
    const ab = $(this).val();
    const $lis = $("ul>li");
      const strName = ab;

      slideTarget(strName.substr(4, 1));
        function slideTarget(n) {
            let datelis;
           if (n == 0) {
           location.reload(true);
           } else if (n === "1") {
            // 날짜 내림차순
          datelis = $lis.sort((a, b) => {
          const dateA = new Date($(a).find("span.date").text());
          const dateB = new Date($(b).find("span.date").text());
          return dateB - dateA; // 내림차순
        });
        }else if (n === "2") {
         // 가격 내림차순
           datelis = $lis.sort((a, b) => {
const priceA = parseInt($(a).find("span.price").text().replace(/[^0-9]/g, ''));
const priceB = parseInt($(b).find("span.price").text().replace(/[^0-9]/g, ''));
          return priceB - priceA;
        });
        }else {
        // 가격 오름차순
        datelis = $lis.sort((a, b) => {
const priceA = parseInt($(a).find("span.price").text().replace(/[^0-9]/g, ''));
const priceB = parseInt($(b).find("span.price").text().replace(/[^0-9]/g, ''));
          return priceA - priceB;
        });
      }
       $("#content ul").html(datelis);
    }
   });
});