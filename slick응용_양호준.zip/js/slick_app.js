$(function(){

  $('.slider').slick({
    autoplay: true,
    infinite: true,
    slidesToShow: 3,
    slidesToScroll: 1,
    dots: true,
    responsive: [
      {
        breakpoint: 769,
        settings: { slidesToShow: 2, slidesToScroll: 1 }
      },
      {
        breakpoint: 480,
        settings: { slidesToShow: 1, slidesToScroll: 1 }
      }
    ]
  });

  $("select.test").on("change", function(){

    const val = $(this).val();
    const n = val.replace("case", "");

    $(".slider").slick("slickUnfilter");

    if (n == "1") {
      $(".slider").slick("slickFilter", $(".slider li.korea"));
    } else if (n == "2") {
      $(".slider").slick("slickFilter", $(".slider li.china"));
    } else if (n == "3") {
      $(".slider").slick("slickFilter", $(".slider li.rome"));
    } else if (n == "4") {
      $(".slider").slick("slickFilter", $(".slider li.egypt"));
    }

  });

});