<?php
  session_start(); 
  include "dbconn.php";

  $num=$_GET['num'];
  $page=$_GET['page'];
 /** @var mysqli $connect */
$sql = "select * from boardlist where num=$num"; 
$result = mysqli_query( $connect,$sql);
$row = mysqli_fetch_array($result);  
$item_num     = $row['num'];
$item_id      = $row['id'];
$item_name    = $row['name'];
$item_hit     = $row['hit'];
$item_date    = $row['regist_day'];
$item_subject = str_replace(" ", "&nbsp;", $row['subject']);
$item_content = $row['content'];
$is_html      = $row['is_html'];

if ($is_html!="y")
{
$item_content = 
str_replace(" ", "&nbsp;", $item_content);
$item_content = 
str_replace("\n", "<br>", $item_content);
}	
	$new_hit = $item_hit + 1;
$sql = "update boardlist set hit=$new_hit 
where num=$num";   // 글 조회수 증가시킴
	mysqli_query( $connect,$sql);
?>
<!DOCTYPE html>
<head> 
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/greet.css">
<script>

</script>
<style>
		#wrap {
	width:1000px;
	margin-right: auto;
	margin-left: auto;
	min-height:600px;
	margin-top:200px;

} 
#content #col2 {
	width:830px;
	min-height:558px;
	float:left;
	margin-left:15px;
}
</style>
</head>
<body>
<div id="wrap">
  <div id="content"> 
  	<div id="col2">
      <div id="title">
			<img src="image/title_greet.gif">
	  </div>
      <div id="view_comment"> &nbsp;</div>
<div id="view_title">
  <div id="view_title1"><?= $item_subject ?></div>
   <div id="view_title2">
	<?= $item_id ?>| 조회 : <?= $item_hit ?> |
    <?= $item_date ?> 
   </div>
</div> <!-- end of view_title -->
       <div id="view_content">
         <!-- content 내용부분 -->
          <?= $item_content ?>
       </div>
    <div id="view_button">
    <a href="list.php?page=<?=$page?>">
	<img src="image/list.png"></a>&nbsp;
<?php
$userid=$_SESSION['userid'];
$item_id=$_SESSION['userid'];
if($userid==$item_id)
{
?>
<a href="modify_form.php?num=<?=$num?>&page=<?=$page?>">
	<img src="image/modify.png"></a>&nbsp;
<a href="delete.php?num=<?=$num?>&page=<?=$page?>">
   <img src="image/delete.png"></a>&nbsp;			
<?
	}
?>
<?php
if($userid)
	{
?>
<a href="write_form.php">
	<img src="image/write.png"></a>
<?
	}
?>

</div>  <!-- end of view_button -->

    <div class="clear"></div>
	</div> <!-- end of col2 -->
  </div> <!-- end of content -->
</div> <!-- end of wrap -->        
</body>
</html>