<? 
	session_start(); 
?>
<!doctype html>
<head> 
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css">
<link rel="stylesheet" href="css/greet.css">
<style>
 p a {font-size:20px;margin-bottom:10px;}
 #wrap {width:1000px; margin-right: auto;
        margin-left: auto;min-height:600px;
        margin-top:200px;}
#header {margin-bottom:200px;}
a {text-decoration:none;color:gray;}

/* 헤더 행 배경색 */
#list_top_title {
  border-top: 2px solid #444 !important;
  background-color: #444 !important;
}

/* 헤더 gif 이미지 → 흰 글씨 텍스트 */
#list_top_title img { display: none !important; }
#list_title1::after { content: "번호"; color: #fff; font-size: 12px; }
#list_title2::after { content: "제목"; color: #fff; font-size: 12px; }
#list_title3::after { content: "글쓴이"; color: #fff; font-size: 12px; }
#list_title4::after { content: "등록일"; color: #fff; font-size: 12px; }
#list_title5::after { content: "조회"; color: #fff; font-size: 12px; }

/* 행 hover */
#list_item:hover { background-color: #f7f7f7; }

/* 이전/다음 링크 스타일 */
#page_num a {
  border: 1px solid #ccc;
  border-radius: 3px;
  padding: 2px 8px;
  color: #444;
}
#page_num a:hover { background: #444; color: #fff; border-color: #444; }
</style>
</head>
<body>
<?php
include "dbconn.php";
	$mode = $_GET['search'];
	$page = $_GET['page'];
	$find = $_POST['find'];
	$search = $_POST['search'];

	if (isset($_GET["mode"]))
    $mode = $_GET["mode"];
  else
    $mode = "";

$scale=10;			// 한 화면에 표시되는 글 수

if($mode == "search")
{
   if(!$search)
		{
			echo("
				<script>
				 window.alert('검색할 단어를 입력해 주세요!');
			     history.go(-1);
				</script>
			");
			exit;
		}
 $sql = "select * from boardlist where $find 
       like '%$search%' order by num desc";   
}
else
{
  $sql = "select * from boardlist order by num desc";
}
/** @var mysqli $connect */
$result = mysqli_query( $connect,$sql);
$total_record = mysqli_num_rows($result); 
if ($total_record % $scale == 0)     
		$total_page = floor($total_record/$scale);
else
		$total_page = floor($total_record/$scale) + 1;
  
if (!$page) 
    $page = 1;

// 표시할 페이지($page)에 따라 $start 계산 
/*
	   1페이지 → 0부터 시작
     2페이지 → 10부터 시작
	*/
  	$start = ($page - 1) * $scale;     
    $number = $total_record - $start;   
?>
<div id="wrap">
<p> <a href="main.html">HOME</a></p>
 <div id="col2">
  <div id="title">BOARD</div>
  <form name="board_form" method="post" action="list.php?mode=search">
    <div id="list_search">
     <div id="list_search1"> ▷ 총 <?= $total_record ?>개의 게시물이 있습니다 </div>
     <div id="list_search2">
        <img src="image/select_search.gif">
     </div>
     <div id="list_search3">
       <select name="find">
         <option value='subject'>제목</option>
         <option value='content'>내용</option>
         <option value='id'>아이디</option>
         <option value='name'>이름</option>
       </select>
     </div>
     <div id="list_search4">
      <input type="text" name="search">
     </div>
     <div id="list_search5">
<input type="image" src="image/list_search_button.gif">    
     </div>
    </div> <!-- #list_search 종료-->
  </form>

<div id="list_top_title">
<ul>
<li id="list_title1">
    <img src="image/list_title1.gif">
</li>
<li id="list_title2">
    <img src="image/list_title2.gif">
</li>
<li id="list_title3">
    <img src="image/list_title3.gif">
</li>
<li id="list_title4">
    <img src="image/list_title4.gif">
</li>
<li id="list_title5">
    <img src="image/list_title5.gif">
</li>
</ul>
</div>

<div id="list_content">
<?php
//현재 페이지에서 보여줄 게시글 10개만 출력하기 위한 반복문	
for($i=$start; $i<$start+$scale && $i < $total_record; $i++)                    
   {
      mysqli_data_seek($result, $i);       
      // 가져올 레코드로 위치(포인터) 이동  
      $row = mysqli_fetch_array($result);       
      // 하나의 레코드 가져오기
	  $item_num     = $row['num'];
	  $item_id      = $row['id'];
	  $item_name    = $row['name'];
 	  $item_hit     = $row['hit'];
    $item_date    = $row['regist_day'];
	  $item_date = substr($item_date, 0, 10);  
/*
//&nbsp;를 공백으로 변환 
$STRING = str_replace("&nbsp;"," ",$STRING);
*/
 $item_subject = str_replace(" ", "&nbsp;", $row['subject']);

?>
<div id="list_item">
		<div id="list_item1"><?= $number ?></div>
		<div id="list_item2">
<a href="view.php?num=<?=$item_num?>&page=<?=$page?>">
  <?= $item_subject ?></a></div>
		<div id="list_item3"><?= $item_id ?></div>
		<div id="list_item4"><?= $item_date ?></div>
		<div id="list_item5"><?= $item_hit ?></div>
</div>
<?
   	   $number--;
   }
?>
   <div id="page_button">
<div id="page_num"> 
<? if($page > 1): ?>
<a href="list.php?page=<?=$page-1?>"> ◀ 이전 </a>
<? else: ?>
◀ 이전
<? endif; ?>
&nbsp;&nbsp;&nbsp;&nbsp; 
<?
   // 게시판 목록 하단에 페이지 링크 번호 출력
   for ($i=1; $i<=$total_page; $i++)
   {
		if ($page == $i)     // 현재 페이지 번호 링크 안함
		{
			echo "<b> $i </b>";
		}
		else
		{ 
			echo "<a href='list.php?page=$i'> $i </a>";
		}      
   }
?>			
&nbsp;&nbsp;&nbsp;&nbsp;
<? if($page < $total_page): ?>
<a href="list.php?page=<?=$page+1?>"> 다음 ▶ </a>
<? else: ?>
다음 ▶
<? endif; ?>
</div>
<div id="button">
<? 
	if($_SESSION['userid'])
	{
?>
		<a href="write_form.php" style="display:inline-block; padding:5px 14px; background:#444; color:#fff; border-radius:4px; font-size:13px; text-decoration:none;">글쓰기</a>
<?
	}
	else
	{
?>
		<a href="login_form.php" style="display:inline-block; padding:5px 14px; background:#444; color:#fff; border-radius:4px; font-size:13px; text-decoration:none;">로그인 후 글쓰기</a>
<?
	}
?>
	</div>
	</div>

</div>
 </div>
</div>
</body>
</html>    