<? 
	session_start(); 
	include "dbconn.php";
	$num=$_GET['num'];

/** @var mysqli $connect */
	$sql = "select * from boardlist where num=$num";
	$result = mysqli_query( $connect,$sql);

	$row = mysqli_fetch_array($result);       	
	$item_subject     = $row['subject'];
	$item_content     = $row['content'];
?>
<html>
<head> 
<meta charset="utf-8">
<link rel="stylesheet" href="css/reset.css">
    <link rel="stylesheet" href="css/exam.css">
<link  rel="stylesheet" href="css/common.css">
<link  rel="stylesheet" href="css/greet.css">

</head>

<body>

<div id="wrap">
  

  <div id="content">
	

	<div id="col2">        
		<div id="title">
			<img src="image/title_greet.gif">
		</div>

		<div class="clear"></div>

		<div id="write_form_title">
			<img src="image/write_form_title.gif">
		</div>
<? $page = 1; ?>
		<div class="clear"></div>
		<form  name="board_form" method="post" action="insert1.php?mode=modify&num=<?=$num?>&page=<?=$page?>"> 
		<div id="write_form">
			<div class="write_line"></div>
			<div id="write_row1">
				<div class="col1"> 닉네임 </div>
				<div class="col2">
					<?=$_SESSION['userid']?>
				</div>
			</div>
			<div class="write_line"></div>
			<div id="write_row2"><div class="col1"> 제목   </div>
			 <div class="col2">
				<input type="text" name="subject" value="<?=$item_subject?>" >
			 </div>
			</div>
			<div class="write_line"></div>
			<div id="write_row3"><div class="col1"> 내용   </div>
			<div class="col2"><textarea rows="15" cols="79" name="content">
				<?=$item_content?></textarea></div>
			</div>
			<div class="write_line"></div>
		</div>

		<div id="write_button"><input type="image" src="image/ok.png">&nbsp;
		<a href="list.php?page=<?=$page?>"><img src="image/list.png"></a>
		</div>  
		</form>

	</div> <!-- end of col2 -->
  </div> <!-- end of content -->
</div> <!-- end of wrap -->

</body>
</html>