<?
	session_start();
?>
<!doctype html>
<html lang="ko">
	<head>
		<meta charset="utf-8">
		<title>html5문서</title>
		<link rel="stylesheet" href="css/reset.css">

<script>
function check_id()
   {
     window.open("check_id.php?id=" + document.member_form.id.value,
         "IDcheck",
          "left=200,top=200,width=200,height=60,scrollbars=no,resizable=yes");
   }
   
   function check_input()
   {

 const re1 =/^(?=.*[a-zA-Z])(?=.*[!@#$%^*+=-])(?=.*[0-9]).{6,10}$/;
    const id=document.member_form.id.value;
      if (!document.member_form.id.value)
      {
          alert("아이디를 입력하세요");    
          document.member_form.id.focus();
          return;
      }else if(!re1.test(id)){
        alert("6~10자의 영문자,숫자,특수기호 혼합해서 사용할 수 있습니다");
    return false;
      }
if (!document.member_form.pass.value)
      {
          alert("비밀번호를 입력하세요");    
          document.member_form.pass.focus();
          return;
      }
	
if (!document.member_form.pass_confirm.value)
      {
          alert("비밀번호확인을 입력하세요");    
          document.member_form.pass_confirm.focus();
          return;
      }

if (document.member_form.pass.value != 
    document.member_form.pass_confirm.value)
{
 alert("비밀번호가 일치하지 않습니다.\n다시 입력해주세요.");
  document.member_form.pass.focus();
  document.member_form.pass.select();
  return; 
}

if (!document.member_form.name.value)
      {
          alert("이름을 입력하세요");    
          document.member_form.name.focus();
          return;
      }

           if (!document.member_form.hp.value)
      {
          alert("휴대폰 번호를 입력하세요");    
          document.member_form.hp.focus();
          return;
      }

   document.member_form.submit();
}

 function reset_form(){
	  document.member_form.id.value = "";
      document.member_form.pass.value = "";
      document.member_form.pass_confirm.value = "";
      document.member_form.name.value = "";
      document.member_form.hp.value = "";
      
      document.member_form.id.focus();

      return;
 }
</script>
<style>
 h2 {text-align:center;margin-bottom:10px;}
 #join1 ul label {display:inline-block;width:120px;}
 #button {margin-top:20px;}
  #join_mem {width:400px;
	transform:translate(-50%,-50%);   
	position:absolute;left:50%;top:50%;
	padding:20px;
    border:1px solid gray;}   
</style>
</head>
<body>
<div id="join_mem">
<h2>회원가입</h2>
        <form  name="member_form" method="post" action="insert.php"> 
	
		<div id="form_join">
			<div id="join1">
			<ul>
			<li> <label for="a1">아이디</label><input type="text" name="id" id="a1">
        <a href="#"><img src="image/check_id.gif" onclick="check_id()"></a>
           </li>
			<li> <label for="a2">비밀번호</label>
            <input type="password" name="pass" id="a2"></li>
			<li> <label for="a3">비밀번호 확인</label>
            <input type="password" name="pass_confirm" id="a3"></li>
	
 <li> <label for="a4">이름</label>
   <input type="text" name="name" id="a4"></li>
            
 <li> <label for="a5">전화번호</label>
   <input type="text" name="hp" id="a5"></li>
</ul>
</div>
			
		</div>

		<div id="button">
			<a href="#">
				<img src="image/button_save.gif"  onclick="check_input()">
			</a>&nbsp;&nbsp;
		    <a href="#">
				<img src="image/button_reset.gif" onclick="reset_form()">
			</a>
		</div>
	    </form>
	</div>

</body>
</html>