<?
 $connect=mysqli_connect( "localhost", "hojoon99", "dkssudgktpdy99!","hojoon99") or  
        die( "SQL server에 연결할 수 없습니다."); 

    mysqli_select_db($connect,"hojoon99");
//localhost, username,pw,dbname
?>