<?
	session_start();
?>
<meta charset="utf-8">
<?php
$id=$_POST['id']; 
if(!$id) {
     echo("
           <script>
             window.alert('아이디를 입력하세요.')
             history.go(-1)
           </script>
         ");
         exit;
   }

   $pass=$_POST['pass'];  
   if(!$pass) {
     echo("
           <script>
             window.alert('비밀번호를 입력하세요.')
             history.go(-1)
           </script>
         ");
         exit;
   }
   //  history.go(-1) : 이전페이지로
   //조회된 데이터가 몇 개 있는지 세어서 $num_match에 넣음
   include "dbconn.php";
/** @var mysqli $connect */
   mysqli_query($connect,'set names utf8');   
   $sql = "select * from mb1 where id='$id'";
   $result = mysqli_query($connect,$sql);
  $num_match = mysqli_num_rows($result); 
if(!$num_match) 
   {
     echo("
           <script>
             window.alert('등록되지 않은 아이디입니다.')
             history.go(-1)
           </script>
         ");
    }else{
        $row = mysqli_fetch_array($result);
        $db_pass = $row['pass'];
        if($pass != $db_pass)
        {
           echo("
              <script>
                window.alert('비밀번호가 틀립니다.')
                history.go(-1)
              </script>
           ");

           exit; 
        }else{
           $userid = $row['id'];
           $_SESSION['userid'] = $userid;  
            echo("
              <script>
                location.href = 'main.html';
              </script>
           ");
        }

    }

?>