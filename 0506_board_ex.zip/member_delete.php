<?
	session_start();
?>
<meta charset="utf-8">
<?php
  include "dbconn.php";
 $sql="delete from mb1 where id='$_SESSION[userid]'";

 //세션 삭제
unset($_SESSION['userid']);
session_destroy();

/** @var mysqli $connect */
mysqli_query( $connect,$sql);
mysqli_close($connect);

echo("
  <script>
   alert('[탈퇴성공] 정상적으로 회원에서 탈퇴하셨습니다.');
   location.href = 'main.html'; 
 </script>
       ");
?>