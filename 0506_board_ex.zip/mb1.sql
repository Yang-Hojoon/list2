create table mb1(
id varchar(15)  not null,
pass varchar(15) not null,
name varchar(8),
hp varchar(20),
primary key(id)
)engine=innoDB charset=utf8;